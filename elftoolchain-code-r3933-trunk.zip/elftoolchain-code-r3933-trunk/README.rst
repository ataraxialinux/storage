The Elftoolchain Project
========================

.. contents:: Table of Contents

.. note::

   If you are reading this README on a mirror site such as GitHub_,
   please note that the primary development site for this project is at
   `elftoolchain.sourceforge.net`_.

   Please use the SourceForge project's `bug tracker`_
   for reporting bugs and for sending in patches.  If you
   have other project-related questions, please ask them on the
   ``<elftoolchain-developers@lists.sourceforge.net>`` `mailing list`_.

.. _GitHub: https://github.com/elftoolchain/elftoolchain
.. _`elftoolchain.sourceforge.net`: http://elftoolchain.sourceforge.net/
.. _`mailing list`: https://sourceforge.net/p/elftoolchain/mailman/elftoolchain-developers/

Description
-----------

This software implements essential compilation tools and libraries for:

- managing program objects conforming to the ELF_ object format, and
- for managing DWARF_ debugging information in ELF objects.

The project currently implements the following utilities and
libraries:

=========== ============================================
Name        Description
=========== ============================================
ar          Archive manager.
addr2line   Debug tool.
brandelf    Manage the ELF brand on executables.
c++filt     Translate encoded symbols.
elfcopy     Copy and translate between object formats.
elfdump     Diagnostic tool.
findtextrel Find undesired text relocations.
libdwarf    DWARF access library.
libelf      ELF access library.
mcs         Manage comment sections.
nm          List symbols in an ELF object.
ranlib      Add archive symbol tables to an archive.
readelf     Display ELF information.
size        List object sizes.
strings     Extract printable strings.
strip       Discard information from ELF objects.
=========== ============================================

.. _ELF: http://en.wikipedia.org/wiki/Executable_and_Linkable_Format
.. _DWARF: http://www.dwarfstd.org/


Project Documentation
---------------------

- Release notes for released versions of this software are present in
  the file ``RELEASE-NOTES`` in the current directory.
- The file ``INSTALL`` in the current directory contains instructions
  on building and installing this software.
- Reference documentation in the form of manual pages is provided for
  the utilities and libraries developed by the project.
- Additional tutorial documentation is present in the
  ``documentation`` directory.


Tracking Ongoing Development
----------------------------

The project uses subversion_ for its version control system.

.. _subversion: https://subversion.apache.org/

The subversion branch for the current set of sources may be accessed
at the following URL::

    https://sourceforge.net/p/elftoolchain/code/HEAD/tree/trunk/

The project's source tree may be checked out from its repository by
using the ``svn checkout`` command::

    % svn checkout https://svn.code.sf.net/p/elftoolchain/code/trunk

Checked-out sources may be kept upto-date by running ``svn update``
inside the source directory::

    % svn update


Instructions on building and installing the software are given in the
file ``INSTALL`` in the current directory.

Downloading Released Software
-----------------------------

Released versions of the project's software may also be downloaded
from SourceForge's `file release system`_.

.. _file release system: http://sourceforge.net/projects/elftoolchain/files/

Copyright and License
---------------------

This code is copyright its authors, and is distributed under the `BSD
License`_.

.. _BSD License: http://www.opensource.org/licenses/bsd-license.php


Developer Community
-------------------

The project's developers may be contacted using the mailing list:
``<elftoolchain-developers@lists.sourceforge.net>``.


Reporting Bugs
--------------

Please use our `bug tracker`_ for viewing existing bug reports and
for submitting new bug reports.

.. _`bug tracker`: https://sourceforge.net/p/elftoolchain/tickets/


Additional Information
----------------------

Additional information about the project may be found on the `project
website`_.

.. _project website:  http://elftoolchain.sourceforge.net/

.. $Id: README.rst 3924 2021-02-26 09:02:10Z jkoshy $

.. Local Variables:
.. mode: rst
.. End:
